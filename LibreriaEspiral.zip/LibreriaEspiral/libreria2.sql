-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 01-12-2020 a las 02:39:36
-- Versión del servidor: 8.0.21
-- Versión de PHP: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `libreria2`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `busquedas`
--

DROP TABLE IF EXISTS `busquedas`;
CREATE TABLE IF NOT EXISTS `busquedas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `palabra` text,
  `fecha` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_busqueda_usuario` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `busquedas`
--

INSERT INTO `busquedas` (`id`, `usuario_id`, `palabra`, `fecha`, `hora`) VALUES
(1, 4, 'Cassandra', '2020-11-30', '18:40:12'),
(2, 4, 'percy', '2020-11-30', '18:53:32'),
(3, 4, 'el ladron del Ray', '2020-11-30', '18:55:57'),
(4, 4, 'el ladrón', '2020-11-30', '18:56:07'),
(5, 4, 'ladrón', '2020-11-30', '18:56:13'),
(6, 2, 'cadena', '2020-11-30', '19:44:24');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

DROP TABLE IF EXISTS `categorias`;
CREATE TABLE IF NOT EXISTS `categorias` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `nombre`) VALUES
(1, 'Costumbrista'),
(2, 'Autobiográfico'),
(3, 'Psicológico'),
(4, 'Terror'),
(5, 'Policíaco'),
(6, 'Misterio'),
(7, 'Ciencia Ficción'),
(8, 'Novela Ligera'),
(9, 'Comics y Manga'),
(10, 'Romance'),
(11, 'Aventura'),
(12, 'Fantasía'),
(13, 'Historico');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `deseos`
--

DROP TABLE IF EXISTS `deseos`;
CREATE TABLE IF NOT EXISTS `deseos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `producto_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_deseos_producto` (`producto_id`),
  KEY `fk_deseos_usuario` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `deseos`
--

INSERT INTO `deseos` (`id`, `usuario_id`, `producto_id`) VALUES
(5, 4, 3),
(16, 4, 3),
(17, 2, 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entradas`
--

DROP TABLE IF EXISTS `entradas`;
CREATE TABLE IF NOT EXISTS `entradas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `producto_id` int NOT NULL,
  `descripcion` text,
  PRIMARY KEY (`id`),
  KEY `fk_entrada_usuario` (`usuario_id`),
  KEY `fk_entrada_producto` (`producto_id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `entradas`
--

INSERT INTO `entradas` (`id`, `usuario_id`, `producto_id`, `descripcion`) VALUES
(1, 2, 3, 'comentario =)'),
(2, 2, 3, 'hi'),
(3, 2, 3, 'hola'),
(4, 2, 3, 'hola2'),
(5, 2, 3, 'hola3'),
(6, 2, 3, 'holaaaaa'),
(7, 2, 6, 'hi'),
(8, 2, 6, 'hola'),
(9, 2, 6, 'hola2'),
(10, 2, 6, 'hola3'),
(11, 2, 8, 'cool'),
(12, 2, 4, 'aaa'),
(13, 2, 2, 'cool'),
(14, 2, 2, 'hola3'),
(15, 2, 8, 'hi'),
(16, 2, 8, 'hola3'),
(17, 2, 5, 'hola3'),
(18, 2, 8, 'lo'),
(19, 2, 6, 'aaaaa'),
(20, 2, 6, 'holaaaaa'),
(21, 2, 6, 'cool'),
(22, 2, 4, 'holaaaaa'),
(23, 2, 8, 'hola3'),
(24, 2, 8, 'hi'),
(25, 2, 8, 'hola'),
(26, 2, 6, 'hola2'),
(27, 2, 8, 'cool'),
(28, 2, 6, 'ss'),
(29, 2, 6, 'ss'),
(30, 2, 6, 'ss'),
(31, 2, 6, 'ss'),
(32, 2, 6, 'ss'),
(33, 2, 6, 'ss'),
(34, 2, 6, 'ss'),
(35, 2, 6, 'ss'),
(36, 2, 6, 'ss'),
(37, 2, 6, 'ss'),
(38, 2, 8, 'ss'),
(39, 2, 8, 'hola2'),
(40, 2, 8, 'hola2'),
(41, 2, 8, 'hola2'),
(42, 2, 8, 'hola2'),
(43, 2, 8, 'hola2'),
(44, 2, 8, 'hola2'),
(45, 2, 8, 'hola2'),
(46, 2, 8, 'hola2'),
(47, 2, 8, 'hola2'),
(48, 2, 8, 'hola2'),
(49, 2, 8, 'hola2'),
(50, 2, 8, 'hola2'),
(51, 2, 8, 'hola2'),
(52, 2, 8, 'hola2'),
(53, 2, 8, 'hola2'),
(54, 2, 8, 'hola2'),
(55, 2, 8, 'hola2'),
(56, 2, 8, 'hola2'),
(57, 2, 8, 'hola2'),
(58, 2, 8, 'hola2'),
(59, 2, 3, 'hola3'),
(60, 2, 3, 'hola3'),
(61, 2, 6, 'ss'),
(62, 2, 6, 'ss'),
(63, 2, 6, 'ss'),
(64, 2, 6, 'hola2'),
(65, 2, 4, 'cool'),
(66, 2, 4, 'cool'),
(67, 2, 4, 'cool'),
(68, 2, 4, 'cool'),
(69, 2, 8, 'hola3'),
(70, 2, 8, 'hola3'),
(71, 2, 8, 'hola3'),
(72, 2, 8, 'hola3'),
(73, 2, 8, 'hola3'),
(74, 2, 5, 'hola'),
(75, 2, 5, 'hi'),
(76, 2, 5, 'hola de prueba definitiva final =)'),
(77, 2, 5, 'este es el ultimo comentario =)'),
(78, 2, 3, 'Este comentario fue el ultimo agregado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lineas_pedidos`
--

DROP TABLE IF EXISTS `lineas_pedidos`;
CREATE TABLE IF NOT EXISTS `lineas_pedidos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pedido_id` int NOT NULL,
  `producto_id` int NOT NULL,
  `unidades` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_linea_pedido` (`pedido_id`),
  KEY `fk_linea_producto` (`producto_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `lineas_pedidos`
--

INSERT INTO `lineas_pedidos` (`id`, `pedido_id`, `producto_id`, `unidades`) VALUES
(1, 1, 4, 1),
(2, 1, 8, 1),
(3, 2, 4, 1),
(4, 2, 8, 1),
(5, 2, 6, 1),
(6, 2, 3, 1),
(7, 3, 3, 1),
(8, 4, 3, 2),
(9, 5, 3, 3),
(10, 5, 6, 1),
(11, 6, 3, 3),
(12, 6, 6, 1),
(13, 6, 8, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
CREATE TABLE IF NOT EXISTS `pedidos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `provincia` varchar(100) NOT NULL,
  `localidad` varchar(100) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `coste` float(200,2) NOT NULL,
  `estado` varchar(20) NOT NULL,
  `fecha` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pedido_usuario` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`id`, `usuario_id`, `provincia`, `localidad`, `direccion`, `coste`, `estado`, `fecha`, `hora`) VALUES
(1, 2, 'Nuevo Leon', 'Monterrey', 'xxx', 570.00, 'confirm', '2020-11-17', '23:19:17'),
(2, 2, 'Nuevo Leon', 'Monterrey', 'no se xd', 1060.00, 'confirm', '2020-11-17', '23:26:04'),
(3, 2, 'aa', 'aa', 'aa', 370.00, 'confirm', '2020-11-19', '21:17:17'),
(4, 4, 'Nuevo Leon', 'Monterrey', 'no se xd', 740.00, 'confirm', '2020-11-27', '01:14:40'),
(5, 4, 'Nuevo Leon', 'Monterrey', 'aa', 1230.00, 'confirm', '2020-11-27', '01:51:18'),
(6, 4, 'Nuevo Leon', 'Monterrey', 'no se xd', 1530.00, 'confirm', '2020-11-27', '03:03:20');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

DROP TABLE IF EXISTS `productos`;
CREATE TABLE IF NOT EXISTS `productos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `categoria_id` int NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `autor` varchar(100) NOT NULL,
  `descripcion` text,
  `editorial` varchar(100) NOT NULL,
  `fecha` int NOT NULL,
  `paginas` int NOT NULL,
  `precio` float(100,2) NOT NULL,
  `formato` int NOT NULL,
  `best` int NOT NULL,
  `stock` int NOT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_producto_categoria` (`categoria_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `categoria_id`, `nombre`, `autor`, `descripcion`, `editorial`, `fecha`, `paginas`, `precio`, `formato`, `best`, `stock`, `imagen`) VALUES
(2, 12, 'Los Orígenes: Princesa Mécanica', 'Cassandra Clare', 'Tessa Gray debería sentirse feliz... ¿Acaso no se sienten así todas las novias? Prometida a Jem, sigue recordando las palabras de Will declarándole su amor. Pero los planes de Mortmain, que necesita a la chica para acabar con los Cazadores de Sombras, cambiarán el destino de Tessa... Si la única manera de salvar el mundo fuera destruyendo a quien más amas, ¿lo haría?', 'Destino', 2013, 570, 350.00, 1, 1, 50, 'clockwork-princess.jpg'),
(3, 12, 'Las Ultimas Horas: Cadena de Oro', 'Cassandra Clare', 'Cordelia Carstairs es una cazadora de sombras, una guerrera entrenada desde la infancia para luchar contra los demonios. Cuando su padre es acusado de un terrible crimen, ella y su hermano viajan al Londres eduardiano con la esperanza de evitar la ruina de la familia. Pero la nueva vida de Cordelia se desmorona cuando una impactante serie de ataques demoníacos devastan Londres. Atrapados en la ciudad, Cordelia y sus amigos descubren que su propia conexión con un oscuro legado les ha otorgado poderes increíbles, y fuerzan una elección brutal que revelará el verdadero precio cruel de ser un héroe.', 'Walker Books', 2020, 672, 370.00, 1, 1, 40, 'cadena-de-oro.jpg'),
(4, 11, 'Percy Jackson y los dioses del Olimpo: El ladrón del rayo', 'Rick Riordan', '¿Qué pasaría si un día descubrieras que, en realidad, eres hijo de un dios griego que debe cumplir una misión secreta? Pues eso es lo que le sucede a Percy Jackson, que a partir de ese momento se dispone a vivir los acontecimientos más emocionantes de su vida.', 'Salamandra', 2005, 288, 270.00, 1, 1, 27, 'el-ladron-del-rayo.jpg'),
(5, 13, 'El Ingenioso Hidalgo Don Quijote De La Mancha', 'Miguel de Cervantes', 'El ingenioso hidalgo don Quijote de la Mancha narra las aventuras de Alonso Quijano, un hidalgo pobre que de tanto leer novelas de caballería acaba enloqueciendo y creyendo ser un caballero andante, nombrándose a sí mismo como don Quijote de la Mancha.', 'Fransico Robles', 1605, 688, 700.00, 1, 1, 10, 'don-quijote-de-la-mancha.jpg'),
(6, 12, 'El principito', 'Antoine de Saint-Exupéry', 'Un piloto se encuentra perdido en el desierto del Sahara después de que su avión sufriera una avería, pero para su sorpresa, es allí donde conoce a un pequeño príncipe proveniente de otro planeta. La historia tiene una temática filosófica, donde se incluyen críticas sociales dirigidas a la «extrañeza» con la que los adultos ven las cosas. Estas críticas a las cosas «importantes» y al mundo de los adultos van apareciendo en el libro a lo largo de la narración.', 'Fransico Robles', 1943, 111, 120.00, 1, 1, 130, 'el-principito.jpg'),
(7, 10, 'Orgullo y prejuicio', 'Jane Austen', 'Jane y Elizabeth son las hermanas mayores de la familia Bennet. Cuando el recién llegado señor Bingley fija sus ojos en la primera, hará las delicias de su madre, ligeramente obsesionada con encontrarles buenos partidos a sus hijas. Todo lo contrario de su amigo, el señor Darcy, quien despierta gran antipatía en la orgullosa Elizabeth a causa de una indiscreción cargada de prejuicios… ¿o es que el prejuicio y el orgullo van de la mano? No importa la respuesta: las cosas no siempre son lo que aparentan.', 'Editorial Porrua', 1813, 291, 250.00, 3, 0, 15, 'orgullo-y-prejuicio.jpg'),
(8, 13, 'Historia de dos ciudades', 'Charles Dickens', 'Hace referencia a París y Londres en los años sacudidos por los muchos y dramáticos acontecimientos que suscitó la Revolución Francesa. Tales son los polos de esta novela llena de acción y aventuras que salta de una orilla a otra del canal de la Mancha y que ofrece un vivo retrato del ambiente y los acontecimientos del París revolucionario dominado por la sombra de la guillotina. Entre los muchos y pintorescos personajes con que Charles Dickens puebla sus páginas, sobresalen los de Charles Darnay y Sidney Carton, quienes, marcados por muy distintos orígenes y peripecias vitales, acaban fundiendo sus existencias como dos caras de una misma moneda.', 'Alianza', 1859, 624, 300.00, 1, 0, 25, 'historia-de-dos-ciudades.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `apellidos` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` varchar(20) DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `apellidos`, `email`, `password`, `rol`, `imagen`) VALUES
(1, 'Admin', 'Admin', 'admin@admin.com', 'contraseña', 'admin', NULL),
(2, 'Mari', 'Meza Cano', 'marichelo.meza@hotmail.com', '$2y$04$cVBuETWWkrexq.qxEgyQ0e4XYipETNUmRewN6jBJPCUjRkOlhXHLu', 'user', NULL),
(3, 'Mari', 'Meza Cano', 'aa@hotmail.com', '$2y$04$zBIJwF1EUwyuSQghRYsrKeESzEHSNKaON88wN3CWT7IlLSbKW8q3q', 'user', NULL),
(4, 'Princesa Mecánica', 'Meza Cano', 'vrms1592@gmail.com', '$2y$04$ljStfBIhylOb/Bog52YCh.3/9tVUI42EEQVN3JptqbGC1ZN33bx82', 'user', NULL);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `busquedas`
--
ALTER TABLE `busquedas`
  ADD CONSTRAINT `fk_busqueda_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `deseos`
--
ALTER TABLE `deseos`
  ADD CONSTRAINT `fk_deseos_producto` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`),
  ADD CONSTRAINT `fk_deseos_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `entradas`
--
ALTER TABLE `entradas`
  ADD CONSTRAINT `fk_entrada_producto` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`),
  ADD CONSTRAINT `fk_entrada_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `lineas_pedidos`
--
ALTER TABLE `lineas_pedidos`
  ADD CONSTRAINT `fk_linea_pedido` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`),
  ADD CONSTRAINT `fk_linea_producto` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`);

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `fk_pedido_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `fk_producto_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
