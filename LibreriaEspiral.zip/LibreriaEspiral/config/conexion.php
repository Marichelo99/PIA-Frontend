<?php


$db = mysqli_connect('localhost', 'root', '', 'libreria');
mysqli_query($db, "SET NAMES 'utf8'");