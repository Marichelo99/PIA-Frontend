<?php
define("base_url", "http://localhost/master-php/LibreriaEspiral/");
define("controller_default", "productoController");
define("action_default", "index");

