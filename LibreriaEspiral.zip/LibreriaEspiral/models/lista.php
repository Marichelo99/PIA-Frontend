<?php
class Lista{
    private $id;
    private $usuario_id;
    private $producto_id;
    
    private $db;
    
    public function __construct() {
        $this->db = Database::connect();
     }
        
    function getId() {
        return $this->id;
    }

    function getUsuario_id() {
        return $this->usuario_id;
    }

    function getProducto_id() {
        return $this->producto_id;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setUsuario_id($usuario_id) {
        $this->usuario_id = $this->db->real_escape_string($usuario_id);
    }

    function setProducto_id($producto_id) {
        $this->producto_id = $this->db->real_escape_string($producto_id);
    }
    
    function saveL(){
        $sql = "INSERT INTO deseos VALUES(NULL, {$this->getUsuario_id()}, {$this->getProducto_id()});";
        $save = $this->db->query($sql);
        $result = false;
        if($save){
                $result = true;
        }
        return $result;

    }
    
    
    function getLista(){
        $sql = "SELECT DISTINCT producto_id, id,nombre,autor,descripcion,precio,imagen from (Select deseos.producto_id, productos.id,productos.nombre,productos.autor,productos.descripcion,productos.precio,productos.imagen FROM deseos RIGHT JOIN productos ON deseos.producto_id = productos.id where deseos.usuario_id = {$this->getUsuario_id()}) As a   ";
       
        $busquedas = $this->db->query($sql);
        return $busquedas;
    }

    function eliminar(){
        $sql = "DELETE FROM deseos where producto_id = {$this->getProducto_id()} AND usuario_id = {$this->getUsuario_id()};";
        $save = $this->db->query($sql);
        $result = false;
        if($save){
                $result = true;
        }
        return $result;
    }
}