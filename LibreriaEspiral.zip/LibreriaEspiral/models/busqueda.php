<?php

class Busqueda{
    private $id;
    private $usuario_id;
    private $palabra;
    private $fecha;
    private $hora;

    function getFecha() {
        return $this->fecha;
    }

    function getHora() {
        return $this->hora;
    }

    function setFecha($fecha) {
        $this->fecha = $fecha;
    }

    function setHora($hora) {
        $this->hora = $hora;
    }

        private $db;
	
    public function __construct() {
            $this->db = Database::connect();
    }
    function getId() {
        return $this->id;
    }

    function getUsuario_id() {
        return $this->usuario_id;
    }

    function getPalabra() {
        return $this->palabra;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setUsuario_id($usuario_id) {
        $this->usuario_id = $this->db->real_escape_string($usuario_id);
    }

    function setPalabra($palabra) {
        $this->palabra = $this->db->real_escape_string($palabra);
    }
    
    function saveB(){
        $sql = "INSERT INTO busquedas VALUES(NULL, {$this->getUsuario_id()}, '{$this->getPalabra()}',  CURDATE(), CURTIME());";
        $save = $this->db->query($sql);

        $result = false;
        if($save){
            $result = true;
        }
        return $result;
        
    }
    function conseguirBusquedas(){
        
        $trozos=explode(" ",$this->getPalabra());
        $numero=count($trozos);
        if ($numero==1) {
            //SI SOLO HAY UNA PALABRA DE BUSQUEDA SE ESTABLECE UNA INSTRUCION CON LIKE
            //$sql="SELECT REFERENCIA, nombre FROM productos WHERE VISIBLE =1 AND autor LIKE '%{$this->getPalabra()}%' OR nombre LIKE '%{$this->getPalabra()}%' LIMIT 50";
            $sql = "SELECT * FROM productos WHERE nombre like '%{$this->getPalabra()}%' or autor like '%{$this->getPalabra()}%'";
            
            } elseif ($numero>1) {
            //SI HAY UNA FRASE SE UTILIZA EL ALGORTIMO DE BUSQUEDA AVANZADO DE MATCH AGAINST
            //busqueda de frases con mas de una palabra y un algoritmo especializado
            //$sql="SELECT REFERENCIA, nombre , MATCH ( nombre, autor ) AGAINST ( '{$this->getPalabra()}' ) AS Score FROM productos WHERE MATCH ( nombre, autor ) AGAINST ( '{$this->getPalabra()}' ) ORDER BY Score DESC LIMIT 50";
            
            $sql = "SELECT * , MATCH (nombre,autor) AGAINST ('{$this->getPalabra()}') AS puntuacion FROM productos WHERE MATCH (nombre, autor) AGAINST ('{$this->getPalabra()}') ORDER BY puntuacion DESC LIMIT 50";
            
            }
         
	//$sql = "SELECT * FROM productos WHERE nombre like '%{$this->getPalabra()}%' or autor like '%{$this->getPalabra()}%'";
	
	        
	$busquedas = $this->db->query($sql);
        
	return $busquedas;
        
    }

    public function HistorialB(){
        $sql = "SELECT * FROM busquedas WHERE usuario_id = {$this->getUsuario_id()} ORDER BY id DESC";

        $busquedas = $this->db->query($sql);
        return $busquedas;
    }
}
