<?php

class Entrada{
    private $id;
    private $usuario_id;
    private $producto_id;
    private $descripcion;
    
    private $db;
        
    public function __construct() {
       $this->db = Database::connect();
    }
        
    function getId() {
        return $this->id;
    }

    function getUsuario_id() {
        return $this->usuario_id;
    }

    function getDescripcion() {
        return $this->descripcion;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setUsuario_id($usuario_id) {
        $this->usuario_id = $this->db->real_escape_string($usuario_id);
    }

    function setDescripcion($descripcion) {
        $this->descripcion = $this->db->real_escape_string($descripcion);
    }
    
    function getProducto_id() {
        return $this->producto_id;
    }

    function setProducto_id($producto_id) {
        $this->producto_id = $this->db->real_escape_string($producto_id);
    }

    function saveE(){
        $sql = "INSERT INTO entradas VALUES(NULL, {$this->getUsuario_id()}, {$this->getProducto_id()}, '{$this->getDescripcion()}');";
        $save = $this->db->query($sql);

        $result = false;
        if($save){
                $result = true;
        }
        return $result;
    }
    
    function getAllEntradas(){
        
        $sql = "SELECT * FROM entradas WHERE producto_id = {$this->getProducto_id()} ORDER BY id DESC";
                
        $entradas = $this->db->query($sql);
        return $entradas;
        
        
    }

}