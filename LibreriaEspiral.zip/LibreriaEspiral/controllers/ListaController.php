<?php
require_once 'models/lista.php';
require_once 'models/producto.php';

class listaController{
    public function guardarL(){
        
            if(isset($_GET['id'])){
                $usuario_id = $_SESSION['identity']->id;

                $producto_id = $_GET['id'];

                $lista = new Lista();
                $lista->setUsuario_id($usuario_id);
                $lista->setProducto_id($producto_id);

                $save = $lista->saveL();
                

                if($save){
                    $_SESSION['lista'] = "complete";
                }else{
                    $_SESSION['lista'] = "failed";
                }

            }else{

                $_SESSION['lista'] = "failed";
            }

            echo "<script type='text/javascript'>";
            echo "window.history.back(-1)";
            echo "</script>";
        
    }
    
    public function mostrarLista(){
        if(isset($_SESSION['identity'])){
            $usuario_id = $_SESSION['identity']->id;
            
            $lista = new Lista();
            $lista->setUsuario_id($usuario_id);
            $listas = $lista->getLista();
            
        }
        
        require_once 'views/usuario/lista_deseos.php';
    }
    
    public function eliminar(){
        if(isset($_GET['id'])){
            $usuario_id = $_SESSION['identity']->id;
            $producto_id = $_GET['id'];

            $lista = new Lista();
            $lista->setUsuario_id($usuario_id);
            $lista->setProducto_id($producto_id);

            $eliminar = $lista->eliminar();


            if($eliminar){
                $_SESSION['lista'] = "complete";
            }else{
                $_SESSION['lista'] = "failed";
            }

        }else{

            $_SESSION['lista'] = "failed";
        }
        echo "<script type='text/javascript'>";
        echo "window.history.back(-1)";
        echo "</script>";
    }
  
}