<?php
require_once 'models/producto.php';

class formatosController{
    
    public function ver(){
        if(isset($_GET['id'])){
            $formato = $_GET['id'];

            // Conseguir productos;
            $producto = new Producto();
            $producto->setFormato($formato);
            $productos = $producto->getFormatos();
        }
        
        
        require_once 'views/formatos/ver.php';
    }
}