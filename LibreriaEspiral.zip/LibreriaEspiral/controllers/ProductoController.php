<?php
require_once 'models/producto.php';
require_once 'models/entrada.php';
require_once 'models/busqueda.php';

class productoController{
	
	public function index(){
                
		$producto = new Producto();
		$productos = $producto->getRandom1(4);
                
                $producto2 = new Producto();
	        $productos2 = $producto2->getRandom2(4);
                
                $producto3 = new Producto();
	        $productos3 = $producto3->getAll();
                
               
		// renderizar vista
		require_once 'views/producto/destacados.php';
	}
	
	public function ver(){
		if(isset($_GET['id'])){
			$id = $_GET['id'];
		
			$producto = new Producto();
			$producto->setId($id);
			
			$product = $producto->getOne();
                      
			// Conseguir entradas;
			$entrada = new Entrada();
			$entrada->setProducto_id($id);
			$entradas = $entrada->getAllEntradas();
			
		}
                
		require 'views/producto/ver.php';
	}
        
        
	public function gestion(){
		Utils::isAdmin();
		
		$producto = new Producto();
		$productos = $producto->getAll();
		
		require_once 'views/producto/gestion.php';
	}
	
	public function crear(){
		Utils::isAdmin();
		require_once 'views/producto/crear.php';
	}
	
	public function save(){
		Utils::isAdmin();
		if(isset($_POST)){
			$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : false;
                        $autor = isset($_POST['autor']) ? $_POST['autor'] : false;
			$descripcion = isset($_POST['descripcion']) ? $_POST['descripcion'] : false;
                        $fecha = isset($_POST['fecha']) ? $_POST['fecha'] : false;
                        $paginas = isset($_POST['paginas']) ? $_POST['paginas'] : false;
			$precio = isset($_POST['precio']) ? $_POST['precio'] : false;
			$stock = isset($_POST['stock']) ? $_POST['stock'] : false;
			$categoria = isset($_POST['categoria']) ? $_POST['categoria'] : false;
                        $editorial = isset($_POST['editorial']) ? $_POST['editorial'] : false;
			// $imagen = isset($_POST['imagen']) ? $_POST['imagen'] : false;
			
			if($nombre && $descripcion && $precio && $stock && $categoria && $autor && $fecha && $paginas && $editorial){
				$producto = new Producto();
				$producto->setNombre($nombre);
                                $producto->setAutor($autor);
				$producto->setDescripcion($descripcion);
                                $producto->setEditorial($editorial);
                                $producto->setFecha($fecha);
                                $producto->setPaginas($paginas);
				$producto->setPrecio($precio);
				$producto->setStock($stock);
				$producto->setCategoria_id($categoria);
                                
                                
				
				// Guardar la imagen
				if(isset($_FILES['imagen'])){
					$file = $_FILES['imagen'];
					$filename = $file['name'];
					$mimetype = $file['type'];

					if($mimetype == "image/jpg" || $mimetype == 'image/jpeg' || $mimetype == 'image/png' || $mimetype == 'image/gif'){

						if(!is_dir('uploads/images')){
							mkdir('uploads/images', 0777, true);
						}

						$producto->setImagen($filename);
						move_uploaded_file($file['tmp_name'], 'uploads/images/'.$filename);
					}
				}
				
				if(isset($_GET['id'])){
					$id = $_GET['id'];
					$producto->setId($id);
					
					$save = $producto->edit();
				}else{
					$save = $producto->save();
				}
				
				if($save){
					$_SESSION['producto'] = "complete";
				}else{
					$_SESSION['producto'] = "failed";
				}
			}else{
				$_SESSION['producto'] = "failed";
			}
		}else{
			$_SESSION['producto'] = "failed";
		}
                echo '<script>window.location="'.base_url.'producto/gestion"</script>';
		//header('Location:'.base_url.'producto/gestion');
	}
	
	public function editar(){
		Utils::isAdmin();
		if(isset($_GET['id'])){
			$id = $_GET['id'];
			$edit = true;
			
			$producto = new Producto();
			$producto->setId($id);
			
			$pro = $producto->getOne();
			
			require_once 'views/producto/crear.php';
			
		}else{
                    echo '<script>window.location="'.base_url.'producto/gestion"</script>';
			//header('Location:'.base_url.'producto/gestion');
		}
	}
	
	public function eliminar(){
		Utils::isAdmin();
		
		if(isset($_GET['id'])){
			$id = $_GET['id'];
			$producto = new Producto();
			$producto->setId($id);
			
			$delete = $producto->delete();
			if($delete){
				$_SESSION['delete'] = 'complete';
			}else{
				$_SESSION['delete'] = 'failed';
			}
		}else{
			$_SESSION['delete'] = 'failed';
		}
		
		header('Location:'.base_url.'producto/gestion');
	}
        
        public function guardarE(){
            if(isset($_POST)){
                $usuario_id = $_SESSION['identity']->id;
                
                $producto_id = $_GET['id'];
                
                $descripcion = isset($_POST['descripcion']) ? $_POST['descripcion'] : false;
                
                if($descripcion){
                    $entrada = new Entrada();
                    $entrada->setUsuario_id($usuario_id);
                    $entrada->setProducto_id($producto_id);
                    $entrada->setDescripcion($descripcion);
                    
                    $save = $entrada->saveE();
                    
                    if($save){
                        $_SESSION['producto'] = "complete";
                    }else{
                        $_SESSION['producto'] = "failed";
                    }
                }else{
                    $_SESSION['producto'] = "failed";
                }
            }else{
                $_SESSION['producto'] = "failed";
            }
                              
            echo "<script type='text/javascript'>";
            echo "window.history.back(-1)";
            echo "</script>";
        }
                
            
        public function buscar(){
            if(isset($_POST)){
                if(isset($_SESSION['identity'])){ //Si la sesion esta activa, que guarde la busqueda para el historial
                    $usuario_id = $_SESSION['identity']->id;
                    
                    $palabra = isset($_POST['palabra']) ? $_POST['palabra'] : false;
                
                    if($palabra){
                        $busqueda = new Busqueda();
                        $busqueda->setUsuario_id($usuario_id);
                        $busqueda->setPalabra($palabra);

                        $save = $busqueda->saveB();
                        $busquedas = $busqueda->conseguirBusquedas();
                        if($save){
                            $_SESSION['busuqeda'] = "complete";
                        }else{
                            $_SESSION['busqueda'] = "failed";
                        }
                    }else{
                        $_SESSION['busqueda'] = "failed";
                    }
		}else{
                    $palabra = isset($_POST['palabra']) ? $_POST['palabra'] : false;
                    if($palabra){
                        $busqueda = new Busqueda();
                        
                        $busqueda->setPalabra($palabra);
                       
                        $busquedas = $busqueda->conseguirBusquedas();
                        
                    }else{
                        $_SESSION['busqueda'] = "failed";
                    }
                }
                
            }else{
                $_SESSION['busqueda'] = "failed";
            }
            require_once 'views/producto/buscar.php';
        }
        
        public function verBusquedas(){
            
            if(isset($_SESSION['identity'])){
                $usuario_id = $_SESSION['identity']->id;
                $busqueda = new Busqueda();
                $busqueda->setUsuario_id($usuario_id);
                $busquedas = $busqueda->HistorialB();
            }
            
            
            require_once 'views/usuario/historial-b.php';
        }
	
       public function best(){
           
           if(isset($_GET['id'])){
                $best = $_GET['id'];
                    
                $producto = new Producto();
                $producto->setBest($best);
                $productos = $producto->getBestSellers();
           }
            require_once 'views/producto/best.php';
       }
       
       public function nosotros(){
           require_once 'views/layout/nosotros.php'; 
        }
}