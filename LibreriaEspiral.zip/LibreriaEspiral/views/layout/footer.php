</div>
</div>

                        <!-- PIE DE PÁGINA -->
                        <footer id="footer">
                            
                            <div id="contacto">
                                <h1>  Contacto</h1>
                                <ul>
                                    <li><a href="https://www.facebook.com"><img src="<?= base_url ?>assets/img/facebook.png" class="img_contacto"  /></a></li>
                                    <li><a href="https://www.twitter.com"><img src="<?= base_url ?>assets/img/twitter.png" class="img_contacto"/></a></li>
                                    <li><a href="https://www.pinterest.com"><img src="<?= base_url ?>assets/img/pinterest.png" class="img_contacto"/></a></li>
                                    <li><a href="https://outlook.live.com/"><img src="<?= base_url ?>assets/img/mail.png" class="img_contacto"/></a></li>
                                    <li><a>Tel: 8115240140</a></li>
                                </ul>
                            </div>
                            <p>Desarrollado por Maria del Consuelo Meza WEB &copy; <?= date('Y') ?></p>
                           
			</footer>
		</div>
	</body>
</html>