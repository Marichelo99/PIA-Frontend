<!DOCTYPE HTML>
<html lang="es">
    <head>
        <meta charset="utf-8"/>
        <title> Libreria</title>
        <link rel="stylesheet" href="<?=base_url?>assets/css/style1.css"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    
    <body>
        <div id="todo">
            <!--Header-->
            <header id="header">
                <div id="logo" >
                    <a href="<?=base_url?>">
                        <img src="<?=base_url?>assets/img/logo1.png" alt="Libro Logo"/>
                        <h1>Libreria Espiral</h1>
                    </a>
                    
                    <?php if(!isset($_SESSION['identity'])): ?>
                        <div id="reg">
                            <a href="<?=base_url?>usuario/registro"><i class="fa fa-user"></i> Inicia sesion o registrate aqui</a>
                            <a href="<?=base_url?>carrito/index"><i class="fa fa-cart-plus"></i> Mi carrito</a>
                        </div>
                        
                    
                    <?php else: ?>
                    
                    <?php $stats = Utils::statsCarrito(); ?>
                        <div class="dropdown">
                            <button class="dropbtn">Bienvenid@ <?=$_SESSION['identity']->nombre?> <?=$_SESSION['identity']->apellidos?></button>

                            <div class="dropdown-content">
                              
                                <a href="<?=base_url?>usuario/logout">Cerrar sesión</a>
                            </div>
                            
                        </div>
                        <div id="bienvenido">
                            <a href="<?=base_url?>carrito/index"><i class="fa fa-cart-plus"></i> Mi carrito</a>
                        </div>  
                    
                    
                    <?php endif; ?>
                    <!--<a href="<?=base_url?>producto/gestion">Gestionar productos</a> -->
                    <!--
                    <ul>
			<?php if(isset($_SESSION['admin'])): ?>
                        <h3>bienvenido <?=$_SESSION['admin']->nombre?> <?=$_SESSION['admin']->apellidos?></h3>
				<li><a href="<?=base_url?>categoria/index">Gestionar categorias</a></li>
				<li><a href="<?=base_url?>producto/gestion">Gestionar productos</a></li>
				<li><a href="<?=base_url?>pedido/gestion">Gestionar pedidos</a></li>
			<?php endif; ?>
			
			<?php if(isset($_SESSION['identity'])): ?>
                        
				<li><a href="<?=base_url?>pedido/mis_pedidos">Mis pedidos</a></li>
				<li><a href="<?=base_url?>usuario/logout">Cerrar sesión</a></li>
			<?php else: ?> 
				
			<?php endif; ?> 
                    </ul>
                        -->
                      
                </div>
                <?php $categorias = Utils::showCategorias(); ?>
                
                
                
                <div id="barra">
                    <ul>
                        
                        <li><a>Menú</a>
                            <ul>
                                <?php $stats = Utils::statsCarrito(); ?>
                                <?php if(!isset($_SESSION['identity'])): ?>
                                    <li><a href="<?=base_url?>usuario/registro"><i class="fa fa-user"></i> Inicia sesion o registrate aqui</a></li>
                                    <li><a href="<?=base_url?>carrito/index"><i class="fa fa-cart-plus"></i>  Mi carrito</a></li>
                                <?php else: ?>
                                    <li><a href="<?=base_url?>carrito/index"><i class="fa fa-cart-plus"></i>  Mi carrito</a></li>
                                    <li><a href="<?=base_url?>lista/mostrarLista"><i class="fa fa-bookmark"></i>  Lista de deseos</a></li>
                                    <li><a href="<?=base_url?>pedido/mis_pedidos"><i class="fa fa-bookmark"></i>  Historial de compras</a></li>
                                    <li><a href="<?=base_url?>producto/verBusquedas"><i class="fa fa-bookmark"></i>  Historial de busquedas</a></li>
                                    <li><a href="<?=base_url?>usuario/logout"><i class="fa fa-sign-out"></i>  Cerrar sesión</a></li>
                                <?php endif; ?>
                            </ul>
                        
                        </li>
                        <li><a href="<?=base_url?>">Inicio</a></li>
                        <li><a>Generos</a>
                            <ul>
                                <?php while($cat = $categorias->fetch_object()): ?>
                                    <li>
                                        <a href="<?=base_url?>categoria/ver&id=<?=$cat->id?>"><?=$cat->nombre?></a>
                                    </li>
					<?php endwhile; ?>
                            </ul>
                        </li>
                        <li><a>Formatos</a>
                            <ul>
                                <li><a href="<?=base_url?>formatos/ver&id=1">Físicos</a></li>
                                <li><a href="<?=base_url?>formatos/ver&id=2">Electronicos</a></li>
                                <li><a href="<?=base_url?>formatos/ver&id=3">Audiolibros</a></li>
                            </ul>
                        
                        </li>
                        <li><a href="<?=base_url?>producto/best&id=1">Best-sellers</a></li>
                        <li><a href="<?=base_url?>producto/nosotros">Sobre nosotros</a></li>
                        
                        <form action="<?=base_url?>producto/buscar" method="POST">
                            <li style="float:right"><button type="submit" formmethod="POST"><i class="fa fa-search"></i> Buscar</button></li>  
                            
                            <li style="float:right"><input type="text" placeholder="Buscar por titulo o autor" name="palabra"/></li>
                
                            
                        </form>
                        
                          
                    </ul>
                </div>
            </header>