<div id="contenido">
    <h1>Sobre nosotros</h1>
    <table id="nosotros">
        <tr>
            <td WIDTH="420">
               
                <img src="<?= base_url ?>assets/img/librero1.png" class="img_nosotros"/>
                
            </td>
            <td>
                <div class="data3">
                    
                    <p class="description2">Somos una empresa mexicana que se dedica hacer un bune de cosas divertidas</p>
                    
                </div>
            </td>
        </tr>

    </table>
    
    
           
        
</div>