<script>
// When the user clicks on <div>, open the popup
function myFunction() {
  var popup = document.getElementById("myPopup");
  popup.classList.toggle("show");
}
</script>

<?php if (isset($categoria)): ?>
<div id="contenido">
    <h1><?= $categoria->nombre ?></h1>
    
	<?php if ($productos->num_rows == 0): ?>
            <p>No hay productos para mostrar</p>
	<?php else: ?>

            <?php while ($product = $productos->fetch_object()): ?>
                <table id="cat">
                    <tr>
                        
                        <td>
                            <a href="<?= base_url ?>producto/ver&id=<?= $product->id ?>">
                            <?php if ($product->imagen != null): ?>
                                    <img src="<?= base_url ?>uploads/images/<?= $product->imagen?>" class="img_carrito"/>
                            <?php else: ?>
                                    <img src="<?= base_url ?>assets/img/Imagen_no_disponible.png" class="img_carrito"/>
                            <?php endif; ?>
                            </a>

                        </td>
                        <td>
                            
                            <div class="data2">
                                <a href="<?= base_url ?>producto/ver&id=<?= $product->id ?>">
                                <h3><?= $product->nombre ?></h3>
                                <p class="price">Precio: $<?= $product->precio ?></p>
                                <p class="autor">Autor: <?= $product->autor ?></p>
                                <h4>Sinopsis:</h4>
                                <p class="description"><?= $product->descripcion ?></p>
                                <a href="<?=base_url?>producto/ver&id=<?=$product->id?>" class="button2">Ver detalles del producto</a>
                                
                                
                            </div>
                           

                        </td>
                    </tr>
                </table>
                
                    
            <?php endwhile; ?>

	<?php endif; ?>
        <?php else: ?>
                <h1>La categoría no existe</h1>
        <?php endif; ?>
    </div>

