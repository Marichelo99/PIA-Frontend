<div id="contenido">
    <h1>Lista de deseos</h1>
    
	<?php if ($listas->num_rows == 0): ?>
            <p>No hay productos en la lista</p>
	<?php else: ?>

            <?php while ($list = $listas->fetch_object()): ?>
                <table id="cat">
                    <tr>
                        
                        <td>
                            <a href="<?= base_url ?>producto/ver&id=<?= $list->id ?>">
                            <?php if ($list->imagen != null): ?>
                                    <img src="<?= base_url ?>uploads/images/<?= $list->imagen?>" class="img_carrito"/>
                            <?php else: ?>
                                    <img src="<?= base_url ?>assets/img/Imagen_no_disponible.png" class="img_carrito"/>
                            <?php endif; ?>
                            </a>

                        </td>
                        <td>
                            
                            <div class="data2">
                                <a href="<?= base_url ?>producto/ver&id=<?= $list->id ?>">
                                <h3><?= $list->nombre ?></h3>
                                <p class="price">Precio: $<?= $list->precio ?></p>
                                <p class="autor">Autor: <?= $list->autor ?></p>
                                <h4>Sinopsis:</h4>
                                <p class="description"><?= $list->descripcion ?></p>
                                <a href="<?=base_url?>producto/ver&id=<?=$list->id?>" class="button2">Ver detalles del producto</a>
                                <a href="<?=base_url?>lista/eliminar&id=<?= $list->id ?>" class="button2">Eliminar de la lista</a>
                                
                            </div>
                           

                        </td>
                    </tr>
                </table>
                
                    
            <?php endwhile; ?>

	<?php endif; ?>
       
    </div>

