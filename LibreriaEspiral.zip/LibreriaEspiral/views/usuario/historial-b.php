<div id="contenido">
    <h1>Historial de busquedas</h1>
    
    <table id="busqueda">
        
        <tr>
            <th WIDTH="30%"><p>Fecha</p></th>
            <th WIDTH="30%"><p>Hora</p></th>
            <th><p>Busqueda</p></th>
            
        </tr>
        <?php while ($bus = $busquedas->fetch_object()): ?>
            <tr>
                <td WIDTH="30%"><p><?= $bus->fecha ?></p></td>
                <td WIDTH="30%"><p><?= $bus->hora ?></p></td>
                <td><p><?= $bus->palabra ?></p></td>
            </tr>
        <?php endwhile; ?>
    </table>

   
</div>