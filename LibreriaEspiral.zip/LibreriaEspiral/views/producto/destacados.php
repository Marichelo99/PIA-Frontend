<div id="contenido">
    <h2>Best-sellers</h2>
    <?php while($product = $productos->fetch_object()): ?>
    <div class="producto">
        <a href="<?=base_url?>producto/ver&id=<?= $product->id ?>">
            <?php if ($product->imagen != null): ?>
                <img src="<?= base_url ?>uploads/images/<?= $product->imagen ?>" />
            <?php else: ?>
                <img src="<?= base_url ?>assets/img/camiseta.png" />
            <?php endif; ?>
            <h3><?= $product->nombre ?></h3>
            <p>$<?= $product->precio ?></p>
        </a>
        
        <a href="<?=base_url?>producto/ver&id=<?= $product->id ?>" class="button">Ver detalles del producto</a>
       
    </div>  
     <?php endwhile; ?>
    

    <h2>Audiolibros</h2>
    
    <?php while($product = $productos2->fetch_object()): ?>
    <div class="producto">
        <a href="<?=base_url?>producto/ver&id=<?= $product->id ?>">
            <?php if ($product->imagen != null): ?>
                <img src="<?= base_url ?>uploads/images/<?= $product->imagen ?>" />
            <?php else: ?>
                <img src="<?= base_url ?>assets/img/camiseta.png" />
            <?php endif; ?>
            <h3><?= $product->nombre ?></h3>
            <p>$<?= $product->precio ?></p>
        </a>
        
        <a href="<?=base_url?>producto/ver&id=<?= $product->id ?>" class="button">Ver detalles del producto</a>
       
    </div>  
     <?php endwhile; ?>
        
</div>




