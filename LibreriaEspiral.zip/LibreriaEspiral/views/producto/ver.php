<script>
// When the user clicks on <div>, open the popup
function myFunction() {
  var popup = document.getElementById("myPopup");
  popup.classList.toggle("show");
}
</script>

<script type="text/javascript">
      function visualiza_primero() {
         document.getElementById('primero').style.visibility='visible';
         document.getElementById('primero')
         document.getElementById('segundo').style.visibility='hidden';
         document.getElementById('segundo')
      };
      function visualiza_segundo() {
         document.getElementById('segundo').style.visibility='visible';
         document.getElementById('segundo')
         document.getElementById('primero').style.visibility='hidden';
         document.getElementById('primero')
      };
   </script>

<?php if (isset($product)): ?>
    <div id="contenido">
        <h1><?= $product->nombre ?></h1>
        
            <table id="cat">
                <tr>
                    <td>
                        <?php if ($product->imagen != null): ?>
                            <img src="<?= base_url ?>uploads/images/<?= $product->imagen?>" class="img_carrito"/>
                        <?php else: ?>
                            <img src="<?= base_url ?>assets/img/Imagen_no_disponible.png" class="img_carrito"/>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="data2">
                            <p class="price">Precio: $<?= $product->precio ?></p>
                            <p class="autor">Autor: <?= $product->autor ?></p>
                            <h4>Sinopsis:</h4>
                            <p class="description2"><?= $product->descripcion ?></p>
                            <a><strong>Editorial: </strong><?= $product->editorial ?> &emsp;</a>
                            <a><strong>Fecha de publicación: </strong><?= $product->fecha ?>&emsp;</a>
                            <a><strong>Paginas: </strong><?= $product->paginas ?>&emsp;</a>
                            <a><strong>Formato: </strong><?= $product->formato ?>&emsp;</a>
                            </br>
                            <p></p>
                            </br>
                            <a href="<?=base_url?>carrito/add&id=<?=$product->id?>" class="button2"><i class="fa fa-cart-plus"></i>   Añadir al carrito </a>
                            
                            <?php if (isset($_SESSION['identity'])): ?>
                                <a href="<?=base_url?>lista/guardarL&id=<?=$product->id?>" id="primero" class="button2" style="visibility:visible;" onclick="visualiza_segundo()"> <i class="fa fa-bookmark"></i>  Añadir al la lista de deseos</a>
                                <a id="segundo" class="button2" style="visibility:hidden;" onclick="visualiza_primero()">Añadido a la lista de deseos</a>
                            <?php else: ?>
                             
                                <div class="popup" onclick="myFunction()"> 
                                    <a class="button2"><i class="fa fa-bookmark"></i>  Añadir al la lista de deseos</a>
                                    <span class="popuptext" id="myPopup">Necesitas iniciar sesión para usar esta función</span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                    
            </table>
           
        
        

        <div id="dejar_c">
            
             <?php if (isset($_SESSION['identity'])): ?>
            <form action="<?= base_url ?>producto/guardarE&id=<?=$product->id?>" method="POST">
                
                <input type="text" placeholder="Escribe un comentario o reseña" name="descripcion" ></input>
      
                <button type="submit" formmethod="POST"> Guardar comentario</button>
            </form>
             <?php else: ?>
                <p>Necesitas inicar sesión para poder dejar comentarios.</p>
            <?php endif; ?>
        </div>


        <div id="comentarios">
            <h3>Comentarios / Reseñas</h3>
            <?php while ($en = $entradas->fetch_object()): ?>
            <table id="comentario">
                <tr>
                    <h4><?= $en->descripcion ?></h4>
                </tr>
                
            </table>
      
            <?php endwhile; ?>
        </div>
    </div>


<?php else: ?>
       <div id="contenido">

            <h1>El producto no existe</h1>
       </div>
<?php endif; ?>
