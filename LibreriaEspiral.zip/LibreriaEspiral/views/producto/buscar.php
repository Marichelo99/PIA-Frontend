
<div id="contenido">
    
    <h1>Busqueda: <?=$_POST['palabra']?></h1>
    <?php 

        if(!empty($busquedas)):
            while ($bus = $busquedas->fetch_object()): ?>
                <table id="cat">
                    <tr>
                        
                        <td>
                            <a href="<?= base_url ?>producto/ver&id=<?= $bus->id ?>">
                            <?php if ($bus->imagen != null): ?>
                                    <img src="<?= base_url ?>uploads/images/<?= $bus->imagen?>" class="img_carrito"/>
                            <?php else: ?>
                                    <img src="<?= base_url ?>assets/img/Imagen_no_disponible.png" class="img_carrito"/>
                            <?php endif; ?>
                            </a>

                        </td>
                        <td>
                            
                            <div class="data2">
                                <a href="<?= base_url ?>producto/ver&id=<?= $bus->id ?>">
                                <h3><?= $bus->nombre ?></h3>
                                <p class="price">Precio: $<?= $bus->precio ?></p>
                                <p class="autor">Autor: <?= $bus->autor ?></p>
                                <h4>Sinopsis:</h4>
                                <p class="description"><?= $bus->descripcion ?></p>
                                <a href="<?=base_url?>producto/ver&id=<?=$bus->id?>" class="button2">Ver detalles del producto</a>
                            </a>
                            </div>
                           

                        </td>
                    </tr>
                </table>
                
                
    <?php
            endwhile;
        else:
    ?>
        <div class="alerta">No hay entradas para esta busqueda</div>
    <?php endif; ?>
         
    
         
	
</div> <!--fin principal-->
			
