<?php /*if (isset($gestion)): ?>
	<h1>Gestionar pedidos</h1>
<?php else: ?>
	<h1>Historial de compras</h1>
<?php endif; */?> 
    <div id="contenido">
        <h1>Historial de compras</h1>
        
                
        <table id="cat1">
            <tr>
                <th>Código de pedido</th>
                <th>Costo total</th>
                <th>Fecha</th>
                <th>Estado</th>
                <th></th>
            </tr>
            <?php while ($ped = $pedidos->fetch_object()):?>

            <tr>
                <td>
                    <div id="dataH">
                        <a><?= $ped->id ?></a>
                    </div>

                </td>
                <td>
                    <div id="dataH">
                        <?= $ped->coste ?> $
                </div>
                    </td>
                <td>
                    <div id="dataH">
                        <?= $ped->fecha ?>
                        </div>
                </td>
                <td>
                    <div id="dataH">
                        <?=Utils::showStatus($ped->estado)?>
                        </div>
                </td>
                <td>
                    <div id="dataH">
                    <a class="button2" href="<?= base_url ?>pedido/detalle&id=<?= $ped->id ?>">Ver detalles del pedido</a>
                    </div>
                </td>
            </tr>

        <?php endwhile; ?>
        </table>
    </div>