<div id="contenido">
<h1>Carrito de la compra</h1>

<?php if(isset($_SESSION['carrito']) && count($_SESSION['carrito']) >= 1): ?>
<table id="c">
    <tr>
        <th>Imagen</th>
        <th>Nombre</th>
        <th>Precio</th>
        <th>Unidades</th>
        <th>Eliminar</th>
    </tr>
    <?php 
        foreach($carrito as $indice => $elemento): 
        $producto = $elemento['producto'];
    ?>
	
    <tr>
        <td>
            <?php if ($producto->imagen != null): ?>
                    <img src="<?= base_url ?>uploads/images/<?= $producto->imagen ?>" class="img_carrito" />
            <?php else: ?>
                    <img src="<?= base_url ?>assets/img/Imagen_no_disponible.png" class="img_carrito" />
            <?php endif; ?>
        </td>
        <td>
            <a href="<?= base_url ?>producto/ver&id=<?=$producto->id?>"><?=$producto->nombre?></a>
        </td>
        <td>
            <a>$<?=$producto->precio?></a>
        </td>
        <td>
            
            <div class="updown-unidades">
                
                <ul id="menu">
                  <li><a href="<?=base_url?>carrito/up&index=<?=$indice?>" class="button">+</a></li>
                  <li><a><?=$elemento['unidades']?></a></li>
                  <li><a href="<?=base_url?>carrito/down&index=<?=$indice?>" class="button">-</a></li>
                </ul>
            </div>
        </td>
        <td>
            <a href="<?=base_url?>carrito/delete&index=<?=$indice?>" class="button2">Quitar producto</a>
        </td>
    </tr>
	
    <?php endforeach; ?>
</table>
<br/>
<div id="contenido">
    <div class="delete-carrito">
            <a href="<?=base_url?>carrito/delete_all">Vaciar carrito</a>
    </div>
    <div class="total-carrito">
            <?php $stats = Utils::statsCarrito(); ?>
            <h3>Precio total: $<?=$stats['total']?></h3>
            <a href="<?=base_url?>pedido/hacer">Hacer pedido</a>
    </div>
</div>
<?php else: ?>
    
        <p>El carrito está vacio, añade algun producto</p>
  
<?php endif; ?>
</div>