CREATE DATABASE Libreria2;
USE Libreria2;

CREATE TABLE usuarios(
id              int(255) auto_increment not null,
nombre          varchar(100) not null,
apellidos       varchar(255),
email           varchar(255) not null,
password        varchar(255) not null,
rol             varchar(20),
imagen          varchar(255),
CONSTRAINT pk_usuarios PRIMARY KEY(id),
CONSTRAINT uq_email UNIQUE(email)  
)ENGINE=InnoDb;

INSERT INTO usuarios VALUES(NULL, 'Admin', 'Admin', 'admin@admin.com', 'contraseña', 'admin', null);

CREATE TABLE categorias(
id              int(255) auto_increment not null,
nombre          varchar(100) not null,
CONSTRAINT pk_categorias PRIMARY KEY(id) 
)ENGINE=InnoDb;


INSERT INTO categorias VALUES(null, 'Costumbrista');
INSERT INTO categorias VALUES(null, 'Autobiográfico');
INSERT INTO categorias VALUES(null, 'Psicológico');
INSERT INTO categorias VALUES(null, 'Terror');
INSERT INTO categorias VALUES(null, 'Policíaco');
INSERT INTO categorias VALUES(null, 'Misterio');
INSERT INTO categorias VALUES(null, 'Ciencia Ficción');
INSERT INTO categorias VALUES(null, 'Novela Ligera');
INSERT INTO categorias VALUES(null, 'Comics y Manga');
INSERT INTO categorias VALUES(null, 'Romance');
INSERT INTO categorias VALUES(null, 'Aventura');
INSERT INTO categorias VALUES(null, 'Fantasía');
INSERT INTO categorias VALUES(null, 'Historico');

CREATE TABLE productos(
id              int(255) auto_increment not null,
categoria_id    int(255) not null,
nombre          varchar(100) not null,
autor           varchar(100) not null,
descripcion     text,
editorial       varchar(100) not null,
fecha           int(255) not null,
paginas         int(255) not null,
precio          float(100,2) not null,
formato         int(10) not null,
best            int(10) not null,
stock           int(255) not null,
imagen          varchar(255),
CONSTRAINT pk_categorias PRIMARY KEY(id),
CONSTRAINT fk_producto_categoria FOREIGN KEY(categoria_id) REFERENCES categorias(id)
)ENGINE=InnoDb;


CREATE TABLE pedidos(
id              int(255) auto_increment not null,
usuario_id      int(255) not null,
provincia       varchar(100) not null,
localidad       varchar(100) not null,
direccion       varchar(255) not null,
coste           float(200,2) not null,
estado          varchar(20) not null,
fecha           date,
hora            time,
CONSTRAINT pk_pedidos PRIMARY KEY(id),
CONSTRAINT fk_pedido_usuario FOREIGN KEY(usuario_id) REFERENCES usuarios(id)
)ENGINE=InnoDb;

CREATE TABLE lineas_pedidos(
id              int(255) auto_increment not null,
pedido_id       int(255) not null,
producto_id     int(255) not null,
unidades        int(255) not null,
CONSTRAINT pk_lineas_pedidos PRIMARY KEY(id),
CONSTRAINT fk_linea_pedido FOREIGN KEY(pedido_id) REFERENCES pedidos(id),
CONSTRAINT fk_linea_producto FOREIGN KEY(producto_id) REFERENCES productos(id)
)ENGINE=InnoDb;

CREATE TABLE entradas(
id              int(255) auto_increment not null,
usuario_id      int(255) not null,
producto_id     int(255) not null,
descripcion     text,
CONSTRAINT pk_entradas PRIMARY KEY(id),
CONSTRAINT fk_entrada_usuario FOREIGN KEY(usuario_id) REFERENCES usuarios(id),
CONSTRAINT fk_entrada_producto FOREIGN KEY(producto_id) REFERENCES productos(id)
)ENGINE=InnoDb;

CREATE TABLE busquedas(
id              int(255) auto_increment not null,
usuario_id      int(255) not null,
palabra         text,
fecha           date,
hora            time,
CONSTRAINT pk_busquedas PRIMARY KEY(id),
CONSTRAINT fk_busqueda_usuario FOREIGN KEY(usuario_id) REFERENCES usuarios(id)
)ENGINE=InnoDb;

CREATE TABLE deseos(
id              int(255) auto_increment not null,
usuario_id      int(255) not null,
producto_id     int(255) not null,
CONSTRAINT pk_deseos PRIMARY KEY(id),
CONSTRAINT fk_deseos_producto FOREIGN KEY(producto_id) REFERENCES productos(id),
CONSTRAINT fk_deseos_usuario FOREIGN KEY(usuario_id) REFERENCES usuarios(id)
)ENGINE=InnoDb;



INSERT INTO `productos`(`id`, `categoria_id`, `nombre`, `autor`, `descripcion`, `editorial`, `fecha`, `paginas`, `precio`, `formato`, `best`,  `stock`, `imagen`) VALUES (null, 12, 'Los Orígenes: Princesa Mécanica', 'Cassandra Clare', 'Tessa Gray debería sentirse feliz... ¿Acaso no se sienten así todas las novias? Prometida a Jem, sigue recordando las palabras de Will declarándole su amor. Pero los planes de Mortmain, que necesita a la chica para acabar con los Cazadores de Sombras, cambiarán el destino de Tessa... Si la única manera de salvar el mundo fuera destruyendo a quien más amas, ¿lo haría?', 'Destino', 2013, 570, 350, 1, 1, 50, 'clockwork-princess.jpg')
INSERT INTO `productos`(`id`, `categoria_id`, `nombre`, `autor`, `descripcion`, `editorial`, `fecha`, `paginas`, `precio`, `formato`, `best`,  `stock`, `imagen`) VALUES (null, 12, 'Las Ultimas Horas: Cadena de Oro', 'Cassandra Clare', 'Cordelia Carstairs es una cazadora de sombras, una guerrera entrenada desde la infancia para luchar contra los demonios. Cuando su padre es acusado de un terrible crimen, ella y su hermano viajan al Londres eduardiano con la esperanza de evitar la ruina de la familia. Pero la nueva vida de Cordelia se desmorona cuando una impactante serie de ataques demoníacos devastan Londres. Atrapados en la ciudad, Cordelia y sus amigos descubren que su propia conexión con un oscuro legado les ha otorgado poderes increíbles, y fuerzan una elección brutal que revelará el verdadero precio cruel de ser un héroe.', 'Walker Books', 2020, 672, 370, 1, 1, 40, 'cadena-de-oro.jpg')
INSERT INTO `productos`(`id`, `categoria_id`, `nombre`, `autor`, `descripcion`, `editorial`, `fecha`, `paginas`, `precio`, `formato`, `best`,  `stock`, `imagen`) VALUES (null, 11, 'Percy Jackson y los dioses del Olimpo: El ladrón del rayo', 'Rick Riordan', '¿Qué pasaría si un día descubrieras que, en realidad, eres hijo de un dios griego que debe cumplir una misión secreta? Pues eso es lo que le sucede a Percy Jackson, que a partir de ese momento se dispone a vivir los acontecimientos más emocionantes de su vida.', 'Salamandra', 2005, 288, 270, 1, 1, 27, 'el-ladron-del-rayo.jpg')
INSERT INTO `productos`(`id`, `categoria_id`, `nombre`, `autor`, `descripcion`, `editorial`, `fecha`, `paginas`, `precio`, `formato`, `best`,  `stock`, `imagen`) VALUES (null, 13, 'El Ingenioso Hidalgo Don Quijote De La Mancha', 'Miguel de Cervantes', 'El ingenioso hidalgo don Quijote de la Mancha narra las aventuras de Alonso Quijano, un hidalgo pobre que de tanto leer novelas de caballería acaba enloqueciendo y creyendo ser un caballero andante, nombrándose a sí mismo como don Quijote de la Mancha.', 'Fransico Robles', 1605, 688, 700, 1, 1, 10, 'don-quijote-de-la-mancha.jpg')
INSERT INTO `productos`(`id`, `categoria_id`, `nombre`, `autor`, `descripcion`, `editorial`, `fecha`, `paginas`, `precio`, `formato`, `best`,  `stock`, `imagen`) VALUES (null, 12, 'El principito', 'Antoine de Saint-Exupéry', 'Un piloto se encuentra perdido en el desierto del Sahara después de que su avión sufriera una avería, pero para su sorpresa, es allí donde conoce a un pequeño príncipe proveniente de otro planeta. La historia tiene una temática filosófica, donde se incluyen críticas sociales dirigidas a la «extrañeza» con la que los adultos ven las cosas. Estas críticas a las cosas «importantes» y al mundo de los adultos van apareciendo en el libro a lo largo de la narración.', 'Fransico Robles', 1943, 111, 120, 1, 1, 130, 'el-principito.jpg')
INSERT INTO `productos`(`id`, `categoria_id`, `nombre`, `autor`, `descripcion`, `editorial`, `fecha`, `paginas`, `precio`, `formato`, `best`,  `stock`, `imagen`) VALUES (null, 10, 'Orgullo y prejuicio', 'Jane Austen', 'Jane y Elizabeth son las hermanas mayores de la familia Bennet. Cuando el recién llegado señor Bingley fija sus ojos en la primera, hará las delicias de su madre, ligeramente obsesionada con encontrarles buenos partidos a sus hijas. Todo lo contrario de su amigo, el señor Darcy, quien despierta gran antipatía en la orgullosa Elizabeth a causa de una indiscreción cargada de prejuicios… ¿o es que el prejuicio y el orgullo van de la mano? No importa la respuesta: las cosas no siempre son lo que aparentan.', 'Editorial Porrua', 1813, 291, 250, 3, 0, 15, 'orgullo-y-prejuicio.jpg')
INSERT INTO `productos`(`id`, `categoria_id`, `nombre`, `autor`, `descripcion`, `editorial`, `fecha`, `paginas`, `precio`, `formato`, `best`,  `stock`, `imagen`) VALUES (null, 13, 'Historia de dos ciudades', 'Charles Dickens', 'Hace referencia a París y Londres en los años sacudidos por los muchos y dramáticos acontecimientos que suscitó la Revolución Francesa. Tales son los polos de esta novela llena de acción y aventuras que salta de una orilla a otra del canal de la Mancha y que ofrece un vivo retrato del ambiente y los acontecimientos del París revolucionario dominado por la sombra de la guillotina. Entre los muchos y pintorescos personajes con que Charles Dickens puebla sus páginas, sobresalen los de Charles Darnay y Sidney Carton, quienes, marcados por muy distintos orígenes y peripecias vitales, acaban fundiendo sus existencias como dos caras de una misma moneda.', 'Alianza', 1859, 624, 300, 1, 0, 25, 'historia-de-dos-ciudades.jpg')